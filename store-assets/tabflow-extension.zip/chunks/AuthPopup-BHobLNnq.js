import{r as i,j as e}from"./client-6mHhEDkH.js";import{b as k,c as P,r as v,d as D,e as B}from"./MessageHandler-BEYsH60w.js";const _=`-- TabFlow Database Setup — paste this entire block and click "Run"

CREATE TABLE IF NOT EXISTS public.user_settings (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  encryption_salt text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.workspaces (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  color text NOT NULL,
  icon text,
  sort_order bigint NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT false,
  version integer NOT NULL DEFAULT 1,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.tabs (
  id text PRIMARY KEY,
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  url text NOT NULL,
  title text NOT NULL,
  favicon_url text,
  sort_order bigint NOT NULL DEFAULT 0,
  is_pinned boolean NOT NULL DEFAULT false,
  last_accessed timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  snapshot jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.active_devices (
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  device_id text NOT NULL,
  device_name text NOT NULL DEFAULT 'Unknown Device',
  claimed_at timestamptz NOT NULL DEFAULT now(),
  last_heartbeat timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id)
);

CREATE INDEX IF NOT EXISTS idx_workspaces_user_id ON public.workspaces(user_id);
CREATE INDEX IF NOT EXISTS idx_workspaces_is_active ON public.workspaces(user_id, is_active);
CREATE INDEX IF NOT EXISTS idx_tabs_workspace_id ON public.tabs(workspace_id);
CREATE INDEX IF NOT EXISTS idx_tabs_user_id ON public.tabs(user_id);
CREATE INDEX IF NOT EXISTS idx_tabs_is_pinned ON public.tabs(workspace_id, is_pinned);
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON public.sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_created_at ON public.sessions(user_id, created_at DESC);

CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS update_workspaces_updated_at ON public.workspaces;
CREATE TRIGGER update_workspaces_updated_at
  BEFORE UPDATE ON public.workspaces
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_tabs_updated_at ON public.tabs;
CREATE TRIGGER update_tabs_updated_at
  BEFORE UPDATE ON public.tabs
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.workspaces ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tabs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.active_devices ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  DROP POLICY IF EXISTS "Users can view own settings" ON public.user_settings;
  DROP POLICY IF EXISTS "Users can insert own settings" ON public.user_settings;
  DROP POLICY IF EXISTS "Users can update own settings" ON public.user_settings;
  DROP POLICY IF EXISTS "Users can delete own settings" ON public.user_settings;
  DROP POLICY IF EXISTS "Users can view own workspaces" ON public.workspaces;
  DROP POLICY IF EXISTS "Users can create own workspaces" ON public.workspaces;
  DROP POLICY IF EXISTS "Users can update own workspaces" ON public.workspaces;
  DROP POLICY IF EXISTS "Users can delete own workspaces" ON public.workspaces;
  DROP POLICY IF EXISTS "Users can view own tabs" ON public.tabs;
  DROP POLICY IF EXISTS "Users can create own tabs" ON public.tabs;
  DROP POLICY IF EXISTS "Users can update own tabs" ON public.tabs;
  DROP POLICY IF EXISTS "Users can delete own tabs" ON public.tabs;
  DROP POLICY IF EXISTS "Users can view own sessions" ON public.sessions;
  DROP POLICY IF EXISTS "Users can create own sessions" ON public.sessions;
  DROP POLICY IF EXISTS "Users can update own sessions" ON public.sessions;
  DROP POLICY IF EXISTS "Users can delete own sessions" ON public.sessions;
  DROP POLICY IF EXISTS "Users can manage their own active device" ON public.active_devices;
END $$;

CREATE POLICY "Users can view own settings" ON public.user_settings FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own settings" ON public.user_settings FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own settings" ON public.user_settings FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete own settings" ON public.user_settings FOR DELETE USING (auth.uid() = user_id);
CREATE POLICY "Users can view own workspaces" ON public.workspaces FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create own workspaces" ON public.workspaces FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own workspaces" ON public.workspaces FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete own workspaces" ON public.workspaces FOR DELETE USING (auth.uid() = user_id);
CREATE POLICY "Users can view own tabs" ON public.tabs FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create own tabs" ON public.tabs FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own tabs" ON public.tabs FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete own tabs" ON public.tabs FOR DELETE USING (auth.uid() = user_id);
CREATE POLICY "Users can view own sessions" ON public.sessions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can create own sessions" ON public.sessions FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own sessions" ON public.sessions FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete own sessions" ON public.sessions FOR DELETE USING (auth.uid() = user_id);
CREATE POLICY "Users can manage their own active device" ON public.active_devices FOR ALL USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.workspaces; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.tabs; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
DO $$ BEGIN ALTER PUBLICATION supabase_realtime ADD TABLE public.active_devices; EXCEPTION WHEN duplicate_object THEN NULL; END $$;
`,W=({onComplete:S,onSkip:p})=>{const[l,r]=i.useState("welcome"),[y,h]=i.useState(""),[E,g]=i.useState(""),[N,b]=i.useState(""),[c,a]=i.useState(!1),[x,m]=i.useState(!1),[O,f]=i.useState(!1),L=async()=>{var o,d;try{await navigator.clipboard.writeText(_),m(!0),setTimeout(()=>m(!1),2e3)}catch{const C=document.getElementById("setup-sql-block");if(C){const T=document.createRange();T.selectNodeContents(C),(o=window.getSelection())==null||o.removeAllRanges(),(d=window.getSelection())==null||d.addRange(T)}}},w=async()=>{b(""),a(!0);try{if(!y.trim()||!E.trim()){b("Both fields are required."),a(!1);return}const o=y.trim().replace(/\/$/,"");if(!o.startsWith("https://")||!o.includes(".supabase.co")){b("URL should look like https://xxxxx.supabase.co"),a(!1);return}const d=await fetch(`${o}/rest/v1/`,{headers:{apikey:E.trim(),Authorization:`Bearer ${E.trim()}`}});if(!d.ok){b(`Connection failed (HTTP ${d.status}). Double-check your URL and anon key.`),a(!1);return}await k(o,E.trim()),P(),v(),r("success")}catch{b("Could not reach the Supabase project. Check your URL and try again.")}finally{a(!1)}};return e.jsx("div",{style:s.container,children:e.jsxs("div",{style:s.card,children:[l==="welcome"&&e.jsxs(e.Fragment,{children:[e.jsx("h1",{style:s.heading,children:"Welcome to TabFlow"}),e.jsx("p",{style:s.body,children:"TabFlow organizes your browser tabs into workspaces. You can use it entirely on this computer, or enable cloud sync to keep your workspaces in sync across multiple devices."}),e.jsx("p",{style:{...s.body,fontWeight:500,color:"#d0d8e0"},children:"Would you like to enable cloud sync?"}),e.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"10px",marginTop:"20px"},children:[e.jsx("button",{style:s.primaryButton,onClick:()=>r("has-account"),children:"Yes, set up cloud sync"}),e.jsx("button",{style:s.secondaryButtonFull,onClick:()=>{chrome.storage.local.set({tabflow_local_only:!0}),p()},children:"No thanks, just use it on this device"})]})]}),l==="has-account"&&e.jsxs(e.Fragment,{children:[e.jsx("h1",{style:s.heading,children:"Cloud Sync Setup"}),e.jsxs("p",{style:s.body,children:["TabFlow uses"," ",e.jsx("a",{href:"https://supabase.com",target:"_blank",rel:"noopener noreferrer",style:s.link,children:"Supabase"})," ","(a free cloud database) to sync your tabs. Your data is end-to-end encrypted — nobody can read it except you."]}),e.jsx("p",{style:{...s.body,fontWeight:500,color:"#d0d8e0"},children:"Do you already have a Supabase project set up for TabFlow?"}),e.jsxs("div",{style:{display:"flex",flexDirection:"column",gap:"10px",marginTop:"20px"},children:[e.jsx("button",{style:s.primaryButton,onClick:()=>{f(!1),r("enter-credentials")},children:"Yes, I have my project URL and key"}),e.jsx("button",{style:s.secondaryButtonFull,onClick:()=>{f(!0),r("new-project")},children:"No, I need to create one (free, ~5 min)"})]}),e.jsx("div",{style:{marginTop:"16px",textAlign:"center"},children:e.jsx("a",{style:{...s.link,fontSize:"13px",cursor:"pointer"},onClick:()=>r("welcome"),children:"Back"})})]}),l==="new-project"&&e.jsxs(e.Fragment,{children:[e.jsx("h1",{style:s.heading,children:"Create a Supabase Project"}),e.jsxs("div",{style:s.instructionBlock,children:[e.jsx("div",{style:s.instructionNumber,children:"1"}),e.jsx("div",{children:e.jsxs("p",{style:s.body,children:["Go to"," ",e.jsx("a",{href:"https://supabase.com/dashboard",target:"_blank",rel:"noopener noreferrer",style:s.link,children:"supabase.com/dashboard"})," ","and create a free account (or sign in)."]})})]}),e.jsxs("div",{style:s.instructionBlock,children:[e.jsx("div",{style:s.instructionNumber,children:"2"}),e.jsx("div",{children:e.jsxs("p",{style:s.body,children:["Click ",e.jsx("strong",{style:{color:"#e0e6ed"},children:"New Project"}),". Pick any name and a strong database password (you won't need this password in TabFlow)."]})})]}),e.jsxs("div",{style:s.instructionBlock,children:[e.jsx("div",{style:s.instructionNumber,children:"3"}),e.jsx("div",{children:e.jsx("p",{style:s.body,children:"Wait for the project to finish setting up (about 1 minute), then continue."})})]}),e.jsxs("div",{style:s.buttonRow,children:[e.jsx("button",{style:s.secondaryButton,onClick:()=>r("has-account"),children:"Back"}),e.jsx("button",{style:s.primaryButton,onClick:()=>r("run-sql"),children:"My Project is Ready"})]})]}),l==="run-sql"&&e.jsxs(e.Fragment,{children:[e.jsx("h1",{style:s.heading,children:"Set Up the Database"}),e.jsxs("div",{style:s.instructionBlock,children:[e.jsx("div",{style:s.instructionNumber,children:"1"}),e.jsx("div",{children:e.jsxs("p",{style:s.body,children:["In your Supabase dashboard, click"," ",e.jsx("strong",{style:{color:"#e0e6ed"},children:"SQL Editor"})," in the left sidebar."]})})]}),e.jsxs("div",{style:s.instructionBlock,children:[e.jsx("div",{style:s.instructionNumber,children:"2"}),e.jsx("div",{children:e.jsxs("p",{style:s.body,children:["Click ",e.jsx("strong",{style:{color:"#e0e6ed"},children:"New Query"}),", paste the SQL below, and click ",e.jsx("strong",{style:{color:"#e0e6ed"},children:"Run"}),"."]})})]}),e.jsxs("div",{style:s.sqlContainer,children:[e.jsxs("div",{style:s.sqlHeader,children:[e.jsx("span",{style:{fontSize:"12px",color:"#8b8fa3"},children:"TabFlow Setup SQL"}),e.jsx("button",{style:s.copyButton,onClick:L,children:x?"Copied!":"Copy"})]}),e.jsx("pre",{id:"setup-sql-block",style:s.sqlBlock,children:_.slice(0,500)+`

  ... (click Copy to get the full script)`})]}),e.jsxs("div",{style:s.buttonRow,children:[e.jsx("button",{style:s.secondaryButton,onClick:()=>r("new-project"),children:"Back"}),e.jsx("button",{style:s.primaryButton,onClick:()=>r("enter-credentials"),children:"I've Run the SQL"})]})]}),l==="enter-credentials"&&e.jsxs(e.Fragment,{children:[e.jsx("h1",{style:s.heading,children:"Connect Your Project"}),e.jsxs("p",{style:s.body,children:["In your Supabase dashboard, go to"," ",e.jsx("strong",{style:{color:"#e0e6ed"},children:"Project Settings"})," (gear icon at the bottom of the left sidebar) → ",e.jsx("strong",{style:{color:"#e0e6ed"},children:"API"}),". Copy the two values below."]}),N&&e.jsx("div",{style:s.errorBox,children:N}),e.jsxs("div",{style:s.formGroup,children:[e.jsx("label",{style:s.label,children:"Project URL"}),e.jsx("input",{style:s.input,type:"text",placeholder:"https://xxxxx.supabase.co",value:y,onChange:o=>h(o.target.value),onFocus:o=>o.currentTarget.style.borderColor="#6c8cff",onBlur:o=>o.currentTarget.style.borderColor="#3a3f4b"}),e.jsx("span",{style:s.hint,children:'Listed as "Project URL" in the API settings'})]}),e.jsxs("div",{style:s.formGroup,children:[e.jsx("label",{style:s.label,children:"Anon / Public Key"}),e.jsx("input",{style:s.input,type:"text",placeholder:"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",value:E,onChange:o=>g(o.target.value),onFocus:o=>o.currentTarget.style.borderColor="#6c8cff",onBlur:o=>o.currentTarget.style.borderColor="#3a3f4b"}),e.jsx("span",{style:s.hint,children:'Listed as "anon public" under Project API keys'})]}),e.jsxs("div",{style:s.buttonRow,children:[e.jsx("button",{style:s.secondaryButton,onClick:()=>r(O?"run-sql":"has-account"),children:"Back"}),e.jsx("button",{style:{...s.primaryButton,opacity:c?.7:1},onClick:w,disabled:c,children:c?"Testing...":"Test Connection"})]})]}),l==="success"&&e.jsxs(e.Fragment,{children:[e.jsx("div",{style:s.successIcon,children:"✓"}),e.jsx("h1",{style:s.heading,children:"Connected!"}),e.jsx("p",{style:s.body,children:"TabFlow is connected to your Supabase project. Next, create an account (or sign in) and set your encryption passphrase."}),e.jsx("button",{style:s.primaryButton,onClick:S,children:"Continue to Sign In"})]})]})})},s={container:{width:"100%",minHeight:"100%",backgroundColor:"#0f1117",display:"flex",alignItems:"center",justifyContent:"center",padding:"40px 20px",fontFamily:'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',boxSizing:"border-box"},card:{width:"100%",maxWidth:"560px",backgroundColor:"#1a1d27",borderRadius:"12px",padding:"36px 32px",border:"1px solid #2a2d3a"},heading:{fontSize:"22px",fontWeight:600,color:"#e0e6ed",marginBottom:"12px",marginTop:0,textAlign:"center"},body:{fontSize:"14px",color:"#9ca3af",lineHeight:1.6,marginBottom:"12px",marginTop:0},instructionBlock:{display:"flex",gap:"14px",alignItems:"flex-start",marginBottom:"16px"},instructionNumber:{width:"26px",height:"26px",borderRadius:"50%",backgroundColor:"#6c8cff",color:"#fff",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"13px",fontWeight:700,flexShrink:0,marginTop:"2px"},sqlContainer:{borderRadius:"8px",border:"1px solid #2a2d3a",overflow:"hidden",marginBottom:"24px"},sqlHeader:{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 12px",backgroundColor:"#12141c",borderBottom:"1px solid #2a2d3a"},copyButton:{backgroundColor:"#6c8cff",color:"#fff",border:"none",borderRadius:"4px",padding:"4px 12px",fontSize:"12px",fontWeight:600,cursor:"pointer"},sqlBlock:{backgroundColor:"#12141c",color:"#8b8fa3",padding:"12px",fontSize:"11px",lineHeight:1.5,overflow:"auto",maxHeight:"180px",margin:0,whiteSpace:"pre-wrap",wordBreak:"break-all"},formGroup:{marginBottom:"18px"},label:{display:"block",fontSize:"13px",fontWeight:500,color:"#d0d8e0",marginBottom:"6px"},input:{width:"100%",padding:"10px 12px",backgroundColor:"#12141c",border:"1px solid #3a3f4b",borderRadius:"6px",color:"#e0e6ed",fontSize:"14px",boxSizing:"border-box",outline:"none",transition:"border-color 0.2s"},hint:{fontSize:"12px",color:"#6b7080",marginTop:"4px",display:"block"},errorBox:{backgroundColor:"#7f1d1d",color:"#fecaca",padding:"12px",borderRadius:"6px",fontSize:"13px",marginBottom:"16px"},buttonRow:{display:"flex",gap:"12px",justifyContent:"flex-end",marginTop:"24px"},primaryButton:{backgroundColor:"#6c8cff",color:"#fff",border:"none",borderRadius:"8px",padding:"10px 24px",fontSize:"14px",fontWeight:600,cursor:"pointer",transition:"opacity 0.15s"},secondaryButton:{backgroundColor:"transparent",color:"#8b8fa3",border:"1px solid #3a3f4b",borderRadius:"8px",padding:"10px 20px",fontSize:"14px",fontWeight:500,cursor:"pointer"},secondaryButtonFull:{backgroundColor:"transparent",color:"#8b8fa3",border:"1px solid #3a3f4b",borderRadius:"8px",padding:"10px 24px",fontSize:"14px",fontWeight:500,cursor:"pointer",width:"100%"},link:{color:"#6c8cff",textDecoration:"none"},successIcon:{width:"56px",height:"56px",borderRadius:"50%",backgroundColor:"#166534",color:"#4ade80",display:"flex",alignItems:"center",justifyContent:"center",fontSize:"28px",fontWeight:700,margin:"0 auto 20px"}},z=({onAuthenticated:S})=>{const[p,l]=i.useState("signin"),[r,y]=i.useState(""),[h,E]=i.useState(""),[g,N]=i.useState(""),[b,c]=i.useState(""),[a,x]=i.useState(!1);i.useEffect(()=>{var t;(t=chrome.storage.session)==null||t.get(["authForm_mode","authForm_email","authForm_password","authForm_passphrase"],n=>{n.authForm_mode&&l(n.authForm_mode),n.authForm_email&&y(n.authForm_email),n.authForm_password&&E(n.authForm_password),n.authForm_passphrase&&N(n.authForm_passphrase)})},[]);const m=(t,n,u)=>{var I;u(n),(I=chrome.storage.session)==null||I.set({[`authForm_${t}`]:n})},O=async t=>{var n;t.preventDefault(),c(""),x(!0);try{if(!r||!h||!g){c("All fields are required"),x(!1);return}if(h.length<6){c("Password must be at least 6 characters"),x(!1);return}if(g.length<8){c("Encryption passphrase must be at least 8 characters"),x(!1);return}let u;p==="signup"?u=await D(r,h):u=await B(r,h),typeof chrome<"u"&&chrome.storage&&(chrome.storage.local.set({encryptionPassphrase:g,userId:u.id}),(n=chrome.storage.session)==null||n.remove(["authForm_mode","authForm_email","authForm_password","authForm_passphrase"])),S&&S(u)}catch(u){const I=u instanceof Error?u.message:"An error occurred";c(I)}finally{x(!1)}},f={backgroundColor:"#1a1d27",color:"#e0e6ed",width:"400px",minHeight:"500px",display:"flex",alignItems:"flex-start",justifyContent:"center",padding:"0",fontFamily:'-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'},L={width:"100%",backgroundColor:"#1a1d27",borderRadius:"0",padding:"24px 20px",boxShadow:"none"},w={fontSize:"24px",fontWeight:"600",marginBottom:"8px",textAlign:"center"},o={fontSize:"14px",color:"#9ca3af",textAlign:"center",marginBottom:"24px"},d={marginBottom:"16px"},C={display:"block",fontSize:"13px",fontWeight:"500",marginBottom:"6px",color:"#d0d8e0"},T={width:"100%",padding:"10px 12px",backgroundColor:"#1a1d27",border:"1px solid #3a3f4b",borderRadius:"6px",color:"#e0e6ed",fontSize:"14px",boxSizing:"border-box",outline:"none",transition:"border-color 0.2s"};({...T});const j={fontSize:"12px",color:"#9ca3af",marginTop:"4px",fontStyle:"italic"},F={width:"100%",padding:"10px",backgroundColor:"#6c8cff",color:"#fff",border:"none",borderRadius:"6px",fontSize:"14px",fontWeight:"600",cursor:a?"not-allowed":"pointer",opacity:a?.7:1,marginTop:"20px",transition:"opacity 0.2s"},U={backgroundColor:"#7f1d1d",color:"#fecaca",padding:"12px",borderRadius:"6px",fontSize:"13px",marginBottom:"16px"},A={textAlign:"center",marginTop:"16px",fontSize:"13px"},R={color:"#6c8cff",cursor:"pointer",textDecoration:"none"};return e.jsx("div",{style:f,children:e.jsxs("form",{style:L,onSubmit:O,children:[e.jsx("h1",{style:w,children:p==="signin"?"Sign In":"Create Account"}),e.jsx("p",{style:o,children:p==="signin"?"Welcome back to TabFlow":"Join TabFlow and sync your tabs"}),b&&e.jsx("div",{style:U,children:b}),e.jsxs("div",{style:d,children:[e.jsx("label",{htmlFor:"tabflow-email",style:C,children:"Email"}),e.jsx("input",{id:"tabflow-email",name:"email",type:"email",autoComplete:"email",value:r,onChange:t=>m("email",t.target.value,y),placeholder:"you@example.com",style:T,onFocus:t=>t.currentTarget.style.borderColor="#6c8cff",onBlur:t=>t.currentTarget.style.borderColor="#3a3f4b",disabled:a,required:!0})]}),e.jsxs("div",{style:d,children:[e.jsx("label",{htmlFor:"tabflow-password",style:C,children:"Password"}),e.jsx("input",{id:"tabflow-password",name:"password",type:"password",autoComplete:p==="signup"?"new-password":"current-password",value:h,onChange:t=>m("password",t.target.value,E),placeholder:"At least 6 characters",style:T,onFocus:t=>t.currentTarget.style.borderColor="#6c8cff",onBlur:t=>t.currentTarget.style.borderColor="#3a3f4b",disabled:a,required:!0})]}),e.jsxs("div",{style:d,children:[e.jsx("label",{htmlFor:"tabflow-passphrase",style:C,children:"Encryption Passphrase"}),e.jsx("input",{id:"tabflow-passphrase",name:"passphrase",type:"password",autoComplete:"off",value:g,onChange:t=>m("passphrase",t.target.value,N),placeholder:"Create a strong passphrase",style:T,onFocus:t=>t.currentTarget.style.borderColor="#6c8cff",onBlur:t=>t.currentTarget.style.borderColor="#3a3f4b",disabled:a,required:!0}),e.jsx("div",{style:j,children:"This passphrase encrypts your data. It never leaves your device."})]}),e.jsx("button",{type:"submit",style:F,disabled:a,children:a?"Please wait...":p==="signin"?"Sign In":"Sign Up"}),e.jsx("div",{style:A,children:p==="signin"?e.jsxs(e.Fragment,{children:["Don't have an account?"," ",e.jsx("a",{style:R,onClick:()=>{var t;l("signup"),c(""),(t=chrome.storage.session)==null||t.set({authForm_mode:"signup"})},children:"Sign up"})]}):e.jsxs(e.Fragment,{children:["Already have an account?"," ",e.jsx("a",{style:R,onClick:()=>{var t;l("signin"),c(""),(t=chrome.storage.session)==null||t.set({authForm_mode:"signin"})},children:"Sign in"})]})})]})})};export{z as A,W as S};
